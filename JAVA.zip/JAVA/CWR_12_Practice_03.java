//import java.util.Scanner;
//public class CWR_12_Practice_03 {
//    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter a string content");
//        String name=sc.nextLine();
//
//        System.out.println("After turning the string to lowercase it becomes : ");
//        System.out.println(name.toLowerCase());
//    }
//}


import java.util.Scanner;
//public class CWR_12_Practice_03 {
//    public static void main(String[] args) {
//        String name1="  Ritesh  Khilari";
//    String replacename=name1.replace(' ', '_');
//
//        System.out.println("After replacing spaces with underscores the content becomes : "+replacename);
//
//    }
//}


//
//import java.util.Scanner;
//public class CWR_12_Practice_03 {
//    public static void main(String[] args) {
//    Scanner sc= new Scanner(System.in);
//
//        System.out.println("Enter a name");
//        String name2=sc.nextLine();
//
//        System.out.printf("Dear ");
//        System.out.printf( name2 );
//        System.out.printf(" thanks a lot for visiting");
//    }
//    }

import java.util.Scanner;
public class CWR_12_Practice_03 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter a string");
        String name=sc.nextLine();
        int value1=name.indexOf("  ");
        int value2=name.indexOf("   ");

        if (value1==-1){
            System.out.println("Double space is not present");
        }
        if (value2==-1){
            System.out.println("triple space is not present");
        }
        if (value1 !=-1){
            System.out.printf("Double space is present at index %d   \n",value1);
        }
        if (value2 !=-1){
            System.out.printf("Triple  space is present at index %d \n",value2);
        }

    }
}