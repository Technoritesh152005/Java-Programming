
import java.util.Scanner;

class Onlinelibrary {
    Scanner sc = new Scanner(System.in);
    String[] Bookscount = new String[100];
    int index = 0;

    public void addBook() {
        for (int i = 0; i <= 100; i++) {
            System.out.println("Enter the Book Details and its Author name");
            Bookscount[index] = sc.nextLine();
            index++;
            break;
        }
        System.out.println("Book added successfully!");
    }

    public String issuebook(String details) {
        for (int i = 0; i < Bookscount.length; i++) {
            if (Bookscount[i] != null && Bookscount[i].equalsIgnoreCase(details)) {
                System.out.println("You have found the book");
                String issuedBook = Bookscount[i];
                Bookscount[i] = null;
                return issuedBook;
            }
        }
        System.out.println("Book not found.");
        return null;
    }
    public void ReturnBook(){

            System.out.println("Enter the book you need to return to Online library");
            for (int i=0;i<Bookscount.length;i++) {
            if (Bookscount[i] == null) {
                Bookscount[i] = sc.nextLine();
                break;
            }
        }




    }

    public void showavailablebooks() {
        boolean found = false;

        for (int i = 0; i < Bookscount.length; i++) {
            if (Bookscount[i] != null) {
                System.out.printf("%s\n", Bookscount[i]);
                found = true;
            }
        }

        if (!found) {
            System.out.println("There are no books available.");
        } else {
            System.out.println("These are all the listed books in the library.");
        }
    }

}
public class CWR_40_Exercise_04 {
    public static void main(String[] args) {
        String data;
        Scanner sc = new Scanner(System.in);
        Onlinelibrary user1 = new Onlinelibrary();

        while (true) {
            System.out.println("\nEnter 1 for AddBook\nEnter 2 For Issue Book\nEnter 3 For ShowbookDetails\nEnter 4 to Exit");
            int num = sc.nextInt();
            sc.nextLine(); // Consume leftover newline

            switch (num) {
                case 1:
                    user1.addBook();
                    break;

                case 2:
                    System.out.println("Enter the Book you need to issue");
                    data = sc.nextLine();
                    user1.issuebook(data);
                    break;

                case 3:user1.showavailablebooks();
                break;

                case 5:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
