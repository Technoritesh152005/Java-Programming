//import com.sun.security.jgss.GSSUtil;
//
//import java.util.Scanner;
//
//Question 1
//class Employee{
//
//    Scanner sc=new Scanner(System.in);
//    int salary;
//    String name;
//    String new_name;
//
//    public int get_salary(String name_employee){
//        System.out.printf("Enter the salary of %s",name_employee);
//        salary=sc.nextInt();
//        sc.nextLine();
//        return salary;
//    }
//    public String get_name(){
//        System.out.println("Enter your name");
//        name=sc.nextLine();
//        return name;
//    }
//    public String Change_name(){
//        System.out.println("Enter the name you would like to change");
//        new_name=sc.nextLine();
//        name=new_name;
//        return name;
//    }
//}

//Question2 ;
//class cellphone{
//
//    public void ringing(String mobile_name){
//        System.out.printf("The cellphone of %s is ringing\n",mobile_name);
//    }
//    public void vibrating(String  mobile_name){
//        System.out.printf("The cellphone of %s  is vibrating\n",mobile_name);
//    }
//}

//Question 3
//class square{
//    int side;
//
//    public void area_of_square(String figure){
//        System.out.printf("The area of %s is %d\n ",figure,side*side);
//    }
//    public void perimeter_of_square(String figure){
//        System.out.printf("The perimeter of %s is %d\n",figure,4*side);
//    }
//}

//Question 4
//class rectangle{
//
//    int side1;
//    int side2;
//    public void area_of_rectangle(String figure){
//        System.out.printf("The area of %s is %d\n ",figure,side1*side2);
//    }
//    public void perimeter_of_rectangle(String figure){
//        int total_length=side1+side2;
//        System.out.printf("The perimeter of %s is %d\n",figure,2*total_length);
//    }
//}

//Question 5
//class circle{
//    int radius;
//
//    public void area_of_circle(String figure){
//        System.out.printf("The area of %s is %f\n ",figure,3.142f*radius*radius);
//    }
//    public void perimeter_of_circle(String figure){
//        System.out.printf("The perimeter of %s is %f\n",figure,2*3.142f*radius);
//    }
//}

public class CWR_31_Practice_08 {
    public static void main(String[] args) {

//        Question 1
//        Employee Ritesh =new Employee();
//
//        Ritesh.get_salary("Ritesh khilari");
//        System.out.printf("The salary of %s is %d","Ritesh khilari",Ritesh.salary);
//
//        Ritesh.get_name();
//        System.out.printf("The name is %s",Ritesh.name);
//
//        Ritesh.Change_name();
//        System.out.printf("The name has been changed to %s",Ritesh.name);

//        Question 2
//        cellphone phone1=new cellphone();
//        cellphone phone2=new cellphone();
//
//        phone1.ringing("samsung");
//        phone1.vibrating("samsung");
//
//        phone2.ringing("Iphone");
//        phone2.vibrating("Iphone");

//        Question 3
//        Creating the object for class square
//        square square1=new square();
//        square square2 =new square();
//
//        String shape1="square1";
//        String shape2="square2";
//
////        Initializing the side of square
//        square1.side=25;
//        square2.side=50;
//
//        square1.area_of_square(shape1);
//        square1.perimeter_of_square(shape1);
//
//        square2.area_of_square(shape2);
//        square2.perimeter_of_square(shape2);


//        Question 4
//        rectangle rectangle1=new rectangle();
//        rectangle rectangle2 =new rectangle();
//
//        String shape1="rectangle1";
//        String shape2="rectangle2";

//        Initializing the side of rectangle
//        rectangle1.side1=25;
//        rectangle1.side2=50;
//        rectangle2.side1=30;
//        rectangle2.side2=35;
//
//        rectangle1.area_of_rectangle(shape1);
//        rectangle1.perimeter_of_rectangle(shape1);
//        rectangle2.area_of_rectangle(shape2);
//        rectangle2.perimeter_of_rectangle(shape2);


//        Question 5
//        Creating the object for class circle
//        circle circle1=new circle();
//        circle circle2 =new circle();
//
//        String shape1="circle1";
//        String shape2="circle2";
//
////        Initializing the side of circle
//        circle1.radius=25;
//        circle2.radius=50;
//
//        circle1.area_of_circle(shape1);
//        circle1.perimeter_of_circle(shape1);
//
//        circle2.area_of_circle(shape2);
//        circle2.perimeter_of_circle(shape2);


    }
}
