import java.util.Scanner;

//Our own exception is created
class UnderAgeException extends Exception{
    public UnderAgeException(String msg){
        super(msg);}
//    This msg is received from throw msg

}
public class CWR_58_Exception_custom_class {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter the age");
        int age=sc.nextInt();
        try{
            if (age<18){
//                Trows the exception to Exception Class through super class
                throw new UnderAgeException("You are below 18 and not able to Drive");
            }else{
                System.out.println("You are eligible to drive");
            }
        }catch (UnderAgeException e) {
//            getmessage is a method in Exception class which return the exception from Exception Class
            System.out.println("Caught: " + e.getMessage());
            e.printStackTrace();  // This line will execute
        }



    }
}
