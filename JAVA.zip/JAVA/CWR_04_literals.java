public class CWR_04_literals {
    public static void main(String[] args) {
        int age = 20;
        short num = 2;
        long large = 23456L;
//        For long float and double it is neccesary to use suffix like l , f , d or L F D because they are necessary to explicitly indicate the data type of numeric literals when the default behavior doesn’t match the required type.

        float dec1 = 34.2f;
        double dec2=8.9d;
//        for double we can give and also not give the suffix
        char alpha='R';
        boolean student =true;
        String  name="Ritesh";


        System.out.println(age);
        System.out.println(num);
        System.out.println(large);
        System.out.println(dec1);
        System.out.println(dec2);
        System.out.println(alpha);
        System.out.println(student);
        System.out.println(name);

    }
}
