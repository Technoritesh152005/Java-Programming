class baap{
    public void method1(){
        System.out.println("Hi i am method 1 of baap class\n");
    }
    public void method2(String a,String b){
        System.out.println("This is method 2 of baap class\n");
        System.out.printf("Mere do biwi hai uske naam hai %s aur %s\n",a,b);
    }
}

class beta extends baap{

    public void method_3(){
        System.out.println("Hi. This is a method of 3 of beta class\n");
    }

    @Override
    public void method2(String a, String b) {

        System.out.println("Hi this is a method 2 of beta class");
        System.out.printf("meri maa ka naam %s aur %s hai\n",a,b);
    }
}

public class CWR_38_method_Overriding {
    public static void main(String[] args) {


//        System.out.println("Method overriding in Java is when a subclass (child class) provides its own specific implementation of a method that is already defined in its superclass (parent class). For overriding, the method in the child class must have the same name, return type, and parameters as in the parent class. It allows the child class to offer its own behavior for the method, enabling polymorphism.\n" +
//                "\n" +
//                "Key points:\n" +
//                "Inheritance: The method must be in both the parent and child class.\n" +
//                "Same Signature: The overridden method should have the same name, return type, and parameters.\n" +
//                "@Override Annotation: This optional annotation helps ensure you're overriding correctly.");

//        baap nashedi=new baap();
//        nashedi.method2("Miakhalifa","Sunnyleone");

        beta aryan=new beta();
        aryan.method2("Miakhalifa","Sunnyleone");


    }
   // Method Overriding in simple terms:

//            👉 Method Overriding means redefining a method in a child class that is already defined in the parent class with the same name, same return type, and same parameters.
//
//💡 Why override?
//    To change or improve the behavior of a method inherited from the parent class.

//

}
