import java.awt.geom.Arc2D;
import java.util.Scanner;
public class CWR_29_Practice_07 {

//    Question 1
//    static void multable(int x) {
//        int product = 1;
//        for (int i = 1; i <= 10; i++) {
//            System.out.printf("%d x %d = %d\n", x, i, x * i);
//        }
//    }

//    Question 2
//    public static void starincr(char symbol){
//
//        for (int i=1;i<=5;i++){
//            for (int j=1;j<=i;j++){
//                System.out.printf("%c",symbol);
//            }
//            System.out.println(" ");
//        }
//    }

//    Question 3
//    public static int SumOfNaturalNumbers(int n){
//        int sum=0;
//        for (int i=0;i<=n;i++){
//            sum=sum+i;
//        }
//        return  sum;
//
//    }

//    Question 4
//public static void starincr(char symbol){
//
//        for (int i=5;i>=1;i--){
//            for (int j=i;j>=1;j--){
//                System.out.printf("%c",symbol);
//            }
//            System.out.println(" ");
//        }
//
//    }

//    Question 5

// public static float average(int ...array){
//     float sum=0;
//     for (int i=0;i< array.length;i++){
//         sum=sum+array[i];
//     }
//    float average=sum/ array.length;
//     if(average>0){
//         return average;
//     }
//     else{
//         return 0;
//     }
// }

//    Question 6
    public static void conversion(float temp){
        float fahr;
        if (temp==0||temp<0){
            System.out.println("Invalid temperature");
        }else {
            fahr= (float) ((temp*1.8)+32);
            System.out.printf("The Temperature in fahrenheit will be %.3f",fahr);
        }
    }

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

//        Question 1
//        int num = 7;
//        multable(num);

//        Question 2
//        char c;
//        System.out.println("Enter the symbol of star u need ");
//        c=sc.next().charAt(0);
//        starincr(c);

//        Question 3
//        int num;
//        int ans;
//        System.out.println("Enter the number of natural till u want the sum");
//        num=sc.nextInt();
//        ans= SumOfNaturalNumbers(num);
//        System.out.printf("%d",ans);

//        Question 4
//        char c;
//        System.out.println("Enter the symbol of star u need ");
//        c=sc.next().charAt(0);
//        starincr(c);

//        Question 5
//       float a = average(30,40,50,60);
//        System.out.printf("The avergae of the following number will be %.3f",a);

//Question 6
        float celcius;
        System.out.println("Enter the tenperature in celcius");
        celcius=sc.nextFloat();
        conversion(celcius);

    }
}