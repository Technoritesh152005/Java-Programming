import java.util.Scanner;
public class CWR_05_Exercise_01 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        // Create Scanner object
        System.out.println("Enter the name of student");
        String name=sc.nextLine();
        System.out.println("Enter the marks of english");
        int eng=sc.nextInt();
        System.out.println("Enter the marks of math");
        int math=sc.nextInt();
        System.out.println("Enter the marks of physics");
        int phys=sc.nextInt();
        System.out.println("Enter the marks of chemistry");
        int chem=sc.nextInt();
        System.out.println("Enter the marks of biology");
        int bio=sc.nextInt();
        int Total=500;
        float TotalMarks=eng+math+phys+chem+bio;
        float perc =(TotalMarks*100)/Total;
        System.out.println("The percentage of "+ name + "is "+perc );





    }
}
