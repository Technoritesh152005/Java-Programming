import java.util.Scanner;
public class CWR_16_Practice_04 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

//        Question 1
//        float sub1,sub2,sub3;
//        System.out.println("Enter the marks of subject 1");
//        sub1=sc.nextFloat();
//        System.out.println("Enter the marks of subject 2");
//        sub2=sc.nextInt();
//        System.out.println("Enter the marks of subject 3");
//        sub3=sc.nextInt();
//
//        float total=sub1+sub2+sub3;
//        float perc=(total/300)*100;
//
//        if (sub1 >=33 && sub2>=33 && sub3>=33 && total>=40){
//            System.out.printf("Congratulations you have passed the exam with percentage of %f \n",perc);
//        }
//        else{
//            System.out.println("You have FAILED The exam");
//        }


//        Question 2
//        System.out.println("Enter your income");
//        float income=sc.nextFloat();
//
//        if (income>=250000 && income <=500000){
//            float tax1=(income/100)*5;
//            System.out.printf("Your tax amount is %.2f \n",tax1);
//        }
//        else if (income>500000 && income<=1000000){
//            float tax2=(income/100)*20;
//            System.out.printf("Your tax amount is %.2f \n",tax2);
//        }
//        else if (income>1000000){
//            float tax3=(income/100)*30;
//            System.out.printf("Your tax amount is %.2f \n",tax3);
//        }
//        else{
//            System.out.println("No need to pay tax just enjoy your life");
//        }

//        QUESTION 3

//        int year;
//        System.out.println("Please enter a year to check whether it is leap year or not");
//        year=sc.nextInt();
//
////        The logic to find whether a year is leap or not is that it must be divisible by 4 but not with 100 or it should be divisible by 400
//        if ((year%4 ==0 && year % 100 != 0)||(year%400 ==0)){
//            System.out.printf("The year %d is a leap year",year);
//        }
//        else{
//            System.out.println("The year is not a leap year");
//        }

//        Question 4

        System.out.println("Enter the website");
        String website=sc.nextLine();

        if (website.endsWith(".com")){
            System.out.println("It is a commercial website");
        }
        else if(website.endsWith(".in")) {
            System.out.println("It is a indian based website");
        }
        else if(website.endsWith(".org")){
            System.out.println("It is an organization website");
        }
        else{
            System.out.println("Invalid website");
        }
    }
}
