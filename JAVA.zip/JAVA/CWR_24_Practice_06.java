import java.util.Scanner;
public class CWR_24_Practice_06 {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);

//        Question1
//        float[] marks;
//        marks=new float[5];
//        float sum=0;
//
//        for(int i=0;i<5;i++){
//            System.out.printf("Enter the marks of subject %d \n",i+1);
//            marks[i]=sc.nextFloat();
//        }
//        for(int j=0;j<5;j++){
//            sum=sum+marks[j];
//        }
//        System.out.printf("The total marks are %.2f \n",sum);

//        Question 2
//        int given_integer=25;
//
//        float[] value;
//        value =new float[5];
//        boolean found=false;
//
//
//        for(int i=0;i<5;i++){
//            System.out.printf("Enter the value %d \n",i+1);
//            value[i]=sc.nextFloat();
//        }
//
//        for (int j=0;j<value.length;j++){
//
//            if (value[j]==given_integer){
//                System.out.println("The element is found");
//                found =true;
//                break;
//            }
//
//        }
//        if (!found) {
//
//            System.out.println("The element is not found");
//        }

//        Question 3
//        int students;
//
//        System.out.println("Enter the total number of students");
//        students=sc.nextInt();
//
//
//        float[] marks;
//        marks=new float[students];
//        float sum=0;
//        float avg;
//
//
//        for(int i=0;i<students;i++){
//            System.out.printf("Enter the marks of physics subject %d \n",i+1);
//            marks[i]=sc.nextFloat();
//        }
//        for(int j=0;j<students;j++){
//            sum=sum+marks[j];
//        }
//
//        avg=sum/students;
//
//        System.out.printf("The total marks are %.2f and the average for physics student are %f \n",sum,avg);


//        Question 4
//        int []roll_number =new int[5];
//
//        for ( int i = 0; i < 5; i++) {
//            System.out.println("Enter the roll number");
//            roll_number[i]=sc.nextInt();
//        }
//
////        Displaying the array in reverse order
//        for (int j=roll_number.length-1;j>=0;j--){
//            System.out.printf("The elements are %d \n",roll_number[j]);
//        }

//        Question 5

//        int size;
//
//        System.out.println("Enter the size");
//        size=sc.nextInt();
//        int []numbers=new int[size];
//
//        for (int i=0;i<size;i++){
//            System.out.println("Enter the elements: ");
//            numbers[i]=sc.nextInt();
//        }
//        int max =numbers[0];
//
//        for (int j=0;j<size;j++){
//
//            if (numbers[j]>max){
//                max=numbers[j];
//            }
//
//        }
//        System.out.printf("The largest element in the array is %d",max);


//
//Question 7
//                System.out.println("Enter the size");
//                int size = sc.nextInt();
//                int[] numbers = new int[size];
//
//                // Taking user input
//                for (int i = 0; i < size; i++) {
//                    System.out.println("Enter the elements: ");
//                    numbers[i] = sc.nextInt();
//                }
//
//                // Initialize min with the first element of the array
//                int min = numbers[0];
//
//                // Find the minimum element
//                for (int j = 0; j < size; j++) {
//                    if (numbers[j] < min) {
//                        min = numbers[j];
//                    }
//                }
//
//                // Output the minimum value
//                System.out.printf("The smallest element in the array is %d\n", min);
//                sc.close();

        int size;
        boolean Issorted=true;
        System.out.println("Enter the size");
        size=sc.nextInt();

        int [] array=new int[size];

        for (int i=0;i<size;i++){
            System.out.println("Enter the elements");
            array[i]=sc.nextInt();
        }

        for (int j=1;j<size;j++){
            if (array[j]<array[j-1]){
                Issorted=false;
                break;
            }
//            it is easy to check for false condition bcz if any one elements get disrupts from its order it is not sorted
        }
        if (Issorted==false){
            System.out.println("the elements are  not sorted");
        }
        else{
            System.out.println("The elements are sorted");
        }



            }
        }




