import java.util.Scanner;
public class CWR_23_2D_array {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        int [][] flats;
        flats = new int [2][3];

        for(int i=0;i<flats.length;i++){
            for (int j=0;j<i;j++){
                System.out.println("Enter the numbers: ");
            }


        }
    }
}
