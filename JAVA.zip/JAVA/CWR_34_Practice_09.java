//class cylinder {
//    int radius;
//    int height;
//    public void set_radius(int rad){
//        this.radius=rad;
//    }
//    public void set_height(int hgt){
//        this.height=hgt;
//    }
//    public int get_radius(){
//        return radius;
//    }
//    public int get_height(){
//        return height;
//    }
//    public float volume() {
//        return 3.142f * radius * radius * height;
//    }
//    public float surface_area(){
//        return 2*3.142f*radius*radius*height;
//    }

//Question 3
//    public cylinder(int rd,int ht){
//        this.radius=rd;
//        this.height=ht;
//    }
//    public int get_radius(){
//        return radius;
//    }
//    public int get_height(){
//        return height;
//    }
//}


//Question 4
//class rectangle{
//    int length,breadth;
//
//    public  rectangle(int len,int brd){
//        this.length=len;
//        this.breadth=brd;
//    }
//    public int get_length(){
//        return length;
//    }
//    public int get_breadth(){
//        return breadth;
//    }
//
//}

//    public class CWR_34_Practice_09 {
//        public static void main(String[] args) {

//        cylinder hp=new cylinder();
//
//        hp.set_radius(44);
//        hp.set_height(30);
//
//        System.out.printf("The height of hp cylinder is %d \n",hp.get_height());
//        System.out.printf("The Radius of hp cylinder is %d\n",hp.get_radius());
//
//        System.out.printf("The volume of cylinder is %f\n",hp.volume());
//        System.out.printf("The surface area of cylinder is %f\n",hp.surface_area());

//Question 3
//        cylinder hp = new cylinder(34, 30);
//        System.out.printf("The radius is %d\n",hp.get_radius());
//        System.out.printf("The height is %d\n",hp.get_height());


//            Question 4
//            rectangle byjus=new rectangle(4,6);
//            System.out.printf("The length is %d and breadth is %d of rectangle",byjus.get_length(),byjus.get_breadth());
//
//        }
//    }
//}













import java.util.Scanner;

class cylinder{
    private float radius;
    private float height;
    public void setRadius(float r){
        this.radius=r;
    }
    public void setheight(float h){
        this.height=h;
    }
    public float getradius(){
        return radius;
    }
    public float getheight(){
        return height;
    }
    public double getsurfacearea(){
        return 2*3.14*radius*radius*height;
    }
    public double getvolume(){
        return 3.14*radius*radius*height;
    }

}

class CWR_34_Practice_09{
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        cylinder c1 = new cylinder();
        cylinder c2=new cylinder();
        float ra;
        System.out.println("Enter the radius of the cylinder\n");
        ra=sc.nextFloat();
        c1.setRadius(ra);

        System.out.println("Enter the height of the cylinder\n");
        float he=sc.nextFloat();
        c1.setheight(he);

        System.out.printf("The surface area of the cylinder will be %f\n",c1.getsurfacearea());
        System.out.printf("The volume of the cylinder will be %f",c1.getvolume());



    }
}