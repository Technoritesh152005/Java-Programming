import java.util.*;

class bank{
    Scanner sc=new Scanner(System.in);
    public void atm()  {

        System.out.println("Enter the amt");
        int amt=sc.nextInt();
        try {
            if(amt>10000){
                throw new Exception("Transaction limit exceeded");
            }
            System.out.println("Transaction completed");
        }catch (Exception e){
            System.out.println(e);
        }
        finally {
            System.out.println("Transaction session ended");
        }




    }
}

public class CWR_60_Finally {
    public static void main(String[] args) {
bank b=new bank();
b.atm();

    }
}
