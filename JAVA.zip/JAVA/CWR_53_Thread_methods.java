class Ritesh extends Thread{

    public void run(){

        try{
            for (int i=0;i<10;i++){
                System.out.println("Hello Hello Hello");
                Thread.sleep(5000);
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
class Ritesh2 extends Thread{
    public  void run(){

        try{
            for (int i=0;i<10;i++){
                System.out.println("RAM RAM RAM");
                Thread.sleep(10000);
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
public class CWR_53_Thread_methods {
    public static void main(String[] args)  {

        Ritesh r1=new Ritesh();
        Ritesh2 r2=new Ritesh2();
        r1.start();

//        Suppose you want r1 thread do complete work or execute completely and ten only move to r2 then use join method
        try {
            r1.join();  // waits for t1 to finish
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted during join");
        }
//        main thread is waiting for r1 to finish.
//
//                If some other thread comes and says "Hey main, stop waiting!", this is called an interruption.
//
//        So Java throws: 👉 InterruptedException

        r2.start();

    }
}
