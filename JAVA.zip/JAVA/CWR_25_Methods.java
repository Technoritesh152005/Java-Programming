public class CWR_25_Methods {
//    method declaration
    static int sum(int x, int y){
        int z=0;
        if (x>y ){
        z=x+y;
        }
        else{
            z=(x+y)*5;
        }
        return z;
    }

    public static void main(String[] args) {

        int a=4;
        int b=5;
        int c;


//        Method call:Here the copy of 4 and 5 is been made into a,b of method
//        If static is not created then there is other way to call the method

//        CWR_25_Methods obj=new CWR_25_Methods();
//        c=obj.sum(a,b);

        c=sum(a,b);

        int a1=10;
        int b1=9;
        int c1;

        c1=sum(a1,b1);

        System.out.println(c);
        System.out.println(c1);


    }
}
