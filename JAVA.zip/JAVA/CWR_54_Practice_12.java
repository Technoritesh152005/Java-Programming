//Question 2 and 1
class gm extends Thread{
    public void run(){
        int i=0;
        while(i<10){
            System.out.println("good morning");
            i++;
        }
    }
}
class wc extends Thread{
    public void run(){
        int i=0;
        while(i<10){
            try{
                Thread.sleep(2000);
            }catch(InterruptedException e){
                System.out.println(e);
            }
            System.out.println("Wlcome future wife");
            i++;
        }
    }
}
public class CWR_54_Practice_12 {
    public static void main(String[] args) {

        //Question 2 and 1
    gm g = new gm();
    wc w=new wc();

    g.setPriority(Thread.MAX_PRIORITY);
    w.setPriority(Thread.MIN_PRIORITY);

        System.out.println(g.getPriority());
        System.out.println(w.getPriority());

    g.start();
        System.out.println(g.getState());
    try{
        g.join();
    } catch (InterruptedException e) {
        throw new RuntimeException(e);
    }

    w.start();

    }
}

//QUestion 5
//class MyThread extends Thread {
//    public void run() {
//        // Get reference to the current thread
//        Thread t = Thread.currentThread();
//
//        System.out.println("Inside run method");
//        System.out.println("Current thread name: " + t.getName());
//        System.out.println("Thread ID: " + t.getId());
//        System.out.println("Thread Priority: " + t.getPriority());
//        System.out.println("Thread State: " + t.getState());
//    }
//}
//
//public class CurrentThreadExample {
//    public static void main(String[] args) {
//        MyThread t1 = new MyThread();
//        t1.setName("MyCustomThread");
//        t1.start();
//
//        // Also from main thread
//        Thread mainThread = Thread.currentThread();
//        System.out.println("Main thread name: " + mainThread.getName());
//    }
//}
