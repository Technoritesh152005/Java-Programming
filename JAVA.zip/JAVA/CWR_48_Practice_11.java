
//Question 1 and 2
//abstract  class pen{
//    abstract void write();
//    abstract void refil();
//}
//class fountainpen extends pen{
//    public void write(){
//        System.out.println("I am writing in fountain pen \n");
//    }
//    public void refil(){
//        System.out.println("I am refiling the pen in Fountain pen\n");
//    }
//    public void changenib(){
//        System.out.println("Changing the nib of the fountain pen\n");
//    }
//}

//Question3
//class Monkey{
//    public void bite(){
//        System.out.println("This monkey can bite also");
//    }
//    public void jump(){
//        System.out.println("These monkey can also jump");
//    }
//}
//
//interface basicanimal{
//    public void eat();
//    public void sleep();
//}
//
//class Human  extends   Monkey implements basicanimal{
//    public void eat(){
//        System.out.println("The human also eats like animal");
//    }
//    public void sleep(){
//        System.out.println("The humans also sleep");
//    }
//
//}

//Question 4
//abstract class Telephone{
//
//    abstract void lift();
//    abstract void ring();
//    abstract void disconnect();
//}
//class Smartphone3 extends Telephone{
//    public void lift(){
//        System.out.println("Picking...");
//    }
//    public void ring(){
//        System.out.println("Ringing....");
//    }
//    public void disconnect(){
//        System.out.println("Disconnecting...");
//    }
//}

//Question6
public class CWR_48_Practice_11 {
    public static void main(String[] args) {
        //Question 1 and 2
    //pen p=new fountainpen();
    //p.refil();
    //p.write();
    //
    //fountainpen pr=new fountainpen();
    //pr.changenib();

//        Question 3

//       Human h=new Human();
//       h.eat();
//       h.sleep();
//       h.jump();
//       h.bite();
//
//       basicanimal b=new Human();
//       b.eat();

//        Question 4
//        Polymorphism means "many forms."
//        It allows one object to take many forms — mainly, a parent class reference can refer to a child class object.
//        Telephone t=new Smartphone3();
//        t.ring();
//        t.disconnect();
//        t.disconnect();

//        Question 5
//        Monkey m = new Human();
//        m.bite();
//        m.jump();

//        QUstion 6
//        user sc=new user();
//        sc.switchtobinge();
//        sc.changechannel();
//        sc.downvolume();
//        sc.upvolume();
//
//        TVremote t=new user();
//        t.changechannel();
//        t.upvolume();
//        t.downvolume();


    }
}
