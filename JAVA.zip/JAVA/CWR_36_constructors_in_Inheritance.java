// Base class
class base1 {
    // Default constructor (no parameters)
    base1() {
        System.out.println("Hello I am a constructor of base class with no parameter");
    }

    // Parameterized constructor
    base1(int x) {
        System.out.println("Hello I am a constructor of base class with x parameters as: " + x);
    }
}

// Derived class extending base1
class derived1 extends base1 {

    // Default constructor
    derived1() {
        // Implicitly calls super(), i.e., base1()
        System.out.println("Hello I am a constructor of derived1 class with no parameter");
    }

    // Parameterized constructor
    derived1(int x, int y) {
        // Explicitly calling base class constructor with one parameter
        super(x); // This calls base1(int x)
        System.out.printf("Hello I am a constructor of derived1 class with 1 parameter as %d\n", y);
    }
}

// Child class extending derived1
class childofderived extends derived1 {

    // Default constructor
    childofderived() {
        // Implicitly calls super(), i.e., derived1()
        System.out.println("Hello I am a constructor of childofderived class with no parameters");
    }

    // Parameterized constructor
    childofderived(int x, int y, int z) {
        // Explicitly calling derived1's parameterized constructor
        super(x, y); // This will call derived1(int x, int y), which in turn calls base1(x)
        System.out.println("Hello I am a constructor of childofderived class with value of z as: " + z);
    }
}

public class CWR_36_constructors_in_Inheritance {
    public static void main(String[] args) {
        // Creating object of childofderived using parameterized constructor
        // This triggers a chain of constructor calls from base → derived → child
        childofderived b = new childofderived(30, 5, 20);
    }
}
