class myrunnablethread1 implements Runnable{
    public void run(){
        int i=0;
        while(i<5500){
            System.out.println("I am a thread 1");
            i++;
        }

    }
}
class myrunnablethread2 implements Runnable{
    public void run(){

        int i=0;
        while(i<5500){
            System.out.println("I am a thread 2");
            i++;
        }

    }
}
public class CWR_50_Runnable_interface {
    public static void main(String[] args) {

//        Understand runnable interface like apko pehle bullet banani hogi class ke nam se fir gun banane hogi thread se fir bullet gun me dalke ap runnable thread ko run kar sakte hai
        myrunnablethread1 bullet1= new myrunnablethread1();
        Thread gun1=new Thread(bullet1);

//        If we extend thread class we get a loaded gun(bullet = run method)  whereas if we implement runnable interface you have to load the gun with bullet(runnable class object).
        myrunnablethread2 bullet2= new myrunnablethread2();
        Thread gun2=new Thread(bullet2);
        gun1.start();
        gun2.start();

//
//You cannot extend any class using thread
}
}
