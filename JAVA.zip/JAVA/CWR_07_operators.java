public class CWR_07_operators {
    public static void main(String[] args) {
//       1. Arithmetic operators
        int a=10;
        int b=3;
        int c=a%b;
//        modulo operator( gives remainder)
        System.out.println(c);

//       2. Comparision operators
        System.out.println(5==5);
        System.out.println(6==2);

//       3. Logical operators
        System.out.println(290>217 && 206>215);
        System.out.println(290>217 || 206>215);

//       4. Bitwise operation ( it deals with bits only )
//        2 in binary is 10 and 3 is 11

//        10
//        11
//        --------
//        10 ----> 2 and 3 gives 2
        System.out.println(2&3);
        System.out.println(2|3);

    }

}
