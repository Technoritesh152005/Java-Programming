import java.util.Scanner;
import java.util.Random;

class game{
    Scanner sc=new Scanner(System.in);
    int usernumber,noofguess=0,randnum;
    boolean win=true;

    public game() {
        Random rand = new Random();
        randnum = rand.nextInt(100) + 1; // [1, 100]
    }
    public void getinput(){
        System.out.println("Enter the number between 1 to 100");
        usernumber =sc.nextInt();
    }
    public boolean logic(){
        noofguess++;
        if (usernumber==randnum){
            System.out.printf("You have won the game in %d attempts\n",noofguess);
          return true;
        } else if (usernumber>randnum) {
            System.out.println("You have choosed higher number ,Choose small one");
        }
        else{
            System.out.println("You have choosed smaller number,Choose higher one");
        }
        return false;
    }
}
class GuessTheNumber{
    public static void main(String[] args) {
        game user1 = new game();
      boolean haswon=true;
        while (true){
            user1.getinput();
            haswon=user1.logic();
        }
    }

}