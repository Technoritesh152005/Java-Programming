//An abstract class in Java is a class that cannot be instantiated (you can't create objects of it) but can have both abstract and non-abstract methods.
abstract class Animal{

//    Non abstract method
    public void animalmsg(){
        System.out.println("Hello i am a animal");
    }
//    You cannot write body for abstract method. every class which inherits from animal must follow these property and they can behave as they wish
//    Abstract method
    abstract void makesound();
    abstract void gender();
}


class dog1 extends Animal{
    public void dogmsg(){
        System.out.println("These is a dog message");
    }
    public void makesound(){
        System.out.println("They make sound like bhaw bhaw");
    }
    public void gender(){
        System.out.println("they can be any gender");
    }
//    if dog class ko animal class ke abstract method ko run nhi yah fir use nhi karna hai toh dog1 must be initailized as abstract then

}
public class CWR_42_Abstract_class {
    public static void main(String[] args) {

//        It is possible to make an abstract class as an reference
        Animal d= new dog1();
//        Here reference is of animal but object is of dog

        dog1 d2=new dog1();
        d2.makesound();
//You never cant be able to create an object of abstract class

    }
}
//Why Use Abstract Classes in Java?
//We use abstract classes when:
//
//        ✅ 1. We want to define a common structure for all child classes
//Suppose you’re designing a program with different vehicles.

//All vehicles have some common behavior (e.g., start, stop) — but each has a different way of moving.

//IMP

//2. We want to force subclasses to implement some methods
//By writing an abstract method, you are saying:
//        👉 “Every subclass must provide its own version of this method.”