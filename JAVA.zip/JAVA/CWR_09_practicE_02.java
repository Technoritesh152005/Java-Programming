////Q1
import java .util.Scanner;
public class CWR_09_practicE_02{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter a grade");
        char grade=sc.next().charAt(0);
        System.out.println(grade);
//        sc.next is used to take string input of one word and .char(0) states that take only character at index 0 i.e of first element
//        Encrypting
        char gr=(char)(grade+8);
//        as char + any integer no gives int so we are using typecasting method which changes it to char
        System.out.println("After encrypting it becomes : ");
        System.out.println( gr );

//        decrypting
        char grd=(char)(gr-8);
        System.out.println("After decrypting it becomes : ");
        System.out.println( grd );

    }
}

//Q2
//import java.util.Scanner;
//        public class CWR_09_practicE_02
//        {
//            public static void main(String[] args) {
//
//
//                Scanner sc=new Scanner(System.in);
//                System.out.println("enter a number");
//                int num=sc.nextInt();
//                if (num>66){
//                    System.out.println("The number you entered is greater");
//                }
//                else if(num<66){
//                    System.out.println("The given number is smaller ");
//                }
//                else if(num==66){
//                    System.out.println("The given number is equal");
//                }
//
//            }
//}

//Q3
//import java.util.Scanner;
//public class CWR_09_practicE_02
//{
//    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter the value of 'v'");
//        int v1 = sc.nextInt();
//        System.out.println("Enter the value of 'u'");
//        int u1 = sc.nextInt();
//        System.out.println("Enter the value of 'a'");
//        int a1 = sc.nextInt();
//        System.out.println("Enter the value of 's'");
//        int s1 = sc.nextInt();
//
//        int c=(v1*v1 - u1*u1)/(2*a1*s1);
//        System.out.println("From the expression it becomes: ");
//        System.out.println( c );
//    }
//}
