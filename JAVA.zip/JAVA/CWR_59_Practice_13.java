import java.util.Scanner;
//Question 1
//class sum{
//    public void Sum(int num1,int num2){
//        System.out.println("The sum is : "+num1*num2);
//    }
//}

//class sum{
//    public void Sum(int num1,int num2){
//        System.out.println("The sum is : "+num1*num2);
//    }
//}

//Question 2
//class something{
//    public void haha(){
//        int a=5;
//        int b=0;
//        try{
//            if (a<=0||b<=0){
//                throw new Exception("haha");
//            }
//            int c=a/b;
//
//        }catch (Exception e){
//            System.out.println(e.getMessage());
//        }
//    }
//
//    public void hehe(int a,int b){
////        IllegalArgumentException is a Runtime Exception in Java.
////                It is thrown when a method receives an inappropriate or illegal argument.
//        try{
//            if (a<=0||b<=0){
//                throw new IllegalArgumentException("Hehe");
//            }
//            int c=a/b;
//
//        }catch (Exception e){
//            System.out.println(e.getMessage());
//        }
//    }
//}
//        Question 3 4 5

class exception10 extends Exception{
    @Override
    public String toString() {
        return "Error";
    }
}
class ar extends exception10 {
    int[] array = {20, 30, 40, 50};

    public void exc() throws exception10 {
        int retries = 0;

        while (retries < 5)  {
            System.out.println("Enter the index");
            Scanner sc = new Scanner(System.in);
            int n = sc.nextInt();

            if (n < array.length && n >= 0) {
                System.out.println(array[n]);
                return;
            } else {
                System.out.println("Invalid index.Try again");
                retries++;
            }
        }
        throw new exception10();
    }

}
public class CWR_59_Practice_13 {
    public static void main(String[] args) {
//        Question 1
//Syntax error
//        :It is defined as a semicolon expected error,It is mostly done by developer side
//        int a
//        System.out.println(a);

//        Logical error
//        :It is a error that occur when the requested action logic do not get perform. it simply means the program dont act aacc to the logic given to it

//        sum s=new sum();
//        s.Sum(5,6);

//      Runtime error:It is the error that is occured by user end means try to give false or not required input
//        Actually the below two lines r not runtime errors cause;
//        In Java, a char is implicitly convertible to an int. This is because Java treats characters as Unicode values internally.
//
//                The character '$' has a Unicode/ASCII value of 36.
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter num1");
//        int a=sc.nextInt();
//        System.out.println("Enter num2");
//        int b=sc.nextInt();
//        sum s=new sum();
//        s.Sum(a,b);

//        Question 2
//something s=new something();
//s.haha();
//int ss=0;
//s.hehe(7,ss);

//        Question 3 4 5
        ar a=new ar();
        try
        {
        a.exc();
        }catch (Exception e){
            System.out.println(e);
        }

    }
}
//Java Exception Message Summary
//🔹 getMessage()
//
//Returns the message passed via super("message") in constructor.
//
//Use it like: System.out.println(e.getMessage());
//
//        🔹 toString()
//
//Used when you do System.out.println(e);
//
//Can be overridden to return a custom string.
//
//Does not use super("message") unless you include it yourself.

//Jab bhi aap constructor ko use karke super me msg yah throw new exception("msg") inko use karega toh apko e.getmessage()use krna hoga
//jab bhi aap return karoge tostring ko then use e.tostring() or e simply