public class CWR_18_Breaks_and_continue {
    public static void main(String[] args) {

//        for (int i=0; i<=5;i++) {
//            System.out.println(i);
//            if (i == 3) {
//                System.out.println("Break of the loop");
//                break;
//            }
//        }
//            Break is a type of function which functions to terminate the loop irrespective of whether the condition is true

        for (int i = 0; i <= 5; i++) {

            if (i == 3) {
                System.out.println("Break of the loop");
                continue;
            }
            System.out.println(i);
//                continue is used t skip the current iteration in the loop during its function
        }
    }
}