public class CWR_21_Arrays {
    public static void main(String[] args) {
//        Array is a collection of similar data types
//        there are main three ways to initialize arrays

//        1.
//        int[] marks=new int[5];
//        here int[]marks refer to declaration of array where marks ia reference and it points to memory allocation or object of this class

//        2.
//        int marks[];
//        --> declaration
//        marks =new int[9];
//        --> memory allocation

//        3.
//        int []marks={25,45,65,78};
//        here the size is auto updated during the initializing;

    }
}
