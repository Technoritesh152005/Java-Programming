public class CWR_14_Logical_operators {
    public static void main(String[] args) {
        Boolean a=false;
        boolean b= false;

//        Logical AND Operators
        if (a && b){
            System.out.println("both the conditions are true");
        }
        else{
            System.out.println("The conditions are not true");
        }

//        Logical OR Operators
        if (a || b){
            System.out.println("The conditions are true" );
        }
        else{
            System.out.println("The conditions are false");
        }

//        Logical not
        System.out.printf("The Not (a) is : "+!a);

        System.out.printf("The Not (b) is : "+!b);



    }
}
