import java.util.Scanner;
public class CWR_15_Switchcase {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

//        System.out.println("Enter a age");
//        int age=sc.nextInt();


//        IF - ELSE IF LADDER
//        if (age>60){
//            System.out.println("It is better to get retired from work");
//        }
//        else if (age>35){
//            System.out.println("Go and get financially dependent");
//        }
//        else if (age>22){
//            System.out.println("First get  a job");
//        }
//      if and else if statements acts as a ladder where if any one condition meets true then the control skips to next if or any other instructions

//        SWITCH-CASE
        System.out.println("Enter 1 for sunday, Enter 2 for monday , Enter 3 for tuesday, Enter 4 for wednesday, Enter 5 for thursday, Enter 6 for friday, Enter 7 for saturday");
        int var=sc.nextInt();
        switch(var){
            case 1:
                System.out.println("Its Sunday");
            break;
            case 2:
                System.out.println("Its Monday");
            break;
            case 3:
                System.out.println("Its Tuesday");
            break;
            case 4:
                System.out.println("Its Wednesday");
            break;
            case 5:
                System.out.println("Its Thursday");
            break;
            case 6:
                System.out.println("Its Friday");
            break;
            case 7:
                System.out.println("Its Saturday");
            break;
            default:
                System.out.println("You entered a wrong choice");
        }
    }

}
