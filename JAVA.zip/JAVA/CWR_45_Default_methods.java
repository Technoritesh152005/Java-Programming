interface Camera{
    public void takingpic();
    public void takingvideo();

    //A default method in an interface is a method with a default implementation. It allows interfaces to evolve without breaking classes that already implement them.
//    Default method means:
//    It is NOT necessary for implementing classes to override or implement it — unless they want to change the behavior.
//    this is a seperate method and not necessary to imlement it

//    Interface can also have private methods for default methods to use
    private void taking4k(){
        System.out.println("Taking the 4k video");
    }
    default void quality(){
        taking4k();
        System.out.println("The quality of this video is 4K");
    }
}
interface gps{
    public void location();

}
interface  network{

    String[] networkname = new String[3];
    public void gettingnamess(String[] networkname);

}

class cellularphone{
    public void gettingphone(){
        System.out.println("Picking the phone");
    }
    public void Declinecall(){
        System.out.println("declining the phone");
    }
}

class Smartphones extends cellularphone implements Camera ,gps , network{



    public void takingpic(){
        System.out.println("Taking the snap");
    }
    public void takingvideo(){
        System.out.println("Taking the video");
    }
    public void location(){
        System.out.println("Getting the location");
    }
    public void gettingnamess(String[] networknames){
        System.out.println("Available networks:");
        for (int i = 0; i < 3; i++) {
            System.out.println(networknames[i]);
        }
    }

}
class CWR_45_Default_methods{
    public static void main(String[] args) {
        Smartphones sc=new Smartphones();

     String[] network={"Airrtel","Jio","vodafone"};
     sc.gettingnamess(network);

//     you cannot access private method in interface unless you pass it to default method
//     sc.taking4K();-->XXXX
//
        sc.quality();
    }
}