import java.util.Scanner;

public class CWR_10_Strings {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);


//        String name= new String("Ritesh");
//        String acts as an class in java but can be used as an object in java
//        String name="Ritesh";
//        System.out.println("The name is : ");
//        System.out.println(name);

        int a=4;
        float b=9.4567f;
        System.out.printf("The addition of the numbers %d and %f is %.3f \n",a,b,a+b);
//        The System.out.println does not support format specifiers like %d or %f. If you want to format output using these specifiers, you should use System.out.printf or String.format.
        System.out.println("Enter a string \n");
        String name=sc.nextLine();
        System.out.printf("The String you entered is %s \n",name);
    }

}
