//Q1
//import java.util.Scanner;
//public class CWR_06_Practice_01 {
//    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter num1");
//        int num1= sc.nextInt();
//        System.out.println("Enter num2");
//        int num2= sc.nextInt();
//        System.out.println("Enter num3");
//        int num3= sc.nextInt();
//        int sum=num1+num2+num3;
//        System.out.print("The sum of these numbers are: "+sum);
//
//    }
//}

//Q2
//
//import java.util.Scanner;
//public class CWR_06_Practice_01 {
//    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter your name");
//        String name=sc.nextLine();
//        System.out.println("Enter the marks of subject 1");
//        int sub1=sc.nextInt();
//        System.out.println("Enter the marks of subject 2");
//        int sub2=sc.nextInt();
//        System.out.println("Enter the marks of subject 3");
//        int sub3=sc.nextInt();
//        float totalmarks=sub1+sub2+sub3;
//        int total=300;
//        float perc=(totalmarks/total)*100;
//        float cgpa=perc/9.5f;
//        System.out.print("The gpa of");
//        System.out.print( name);
//        System.out.print(" is");
//        System.out.print( cgpa);
//
//    }
//}

//Q3
//import java.util.Scanner;
//public class CWR_06_Practice_01 {
//    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter your name");
//        String name= sc.nextLine();
//        System.out.print("Hello "+name+" have a good day!");
//
//    }
//}

import java.util.Scanner;
public class CWR_06_Practice_01  {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the distance in kilometers");
        float km=sc.nextFloat();
        float miles=km*0.6213f;
        System.out.print("The distance of " +km+" kilometers in miles will be "+miles);

    }
}
