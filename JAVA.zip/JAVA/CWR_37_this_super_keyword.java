class animal{

    int age_animal;

    public animal(int a){
        this.age_animal= a;
        System.out.printf("The age of animal received is %d\n",age_animal);
    }

        public  animal(){
        System.out.println("The animals can eat");
    }
}

class dog extends animal{

    int age_dog;

    public  dog(int d){
        super(90);
        this.age_dog=d;
        System.out.printf("The age of dog received received is %d\n",age_dog);
    }

    public dog(){
        System.out.println("This dog can bark also");
    }
}


    class puppy extends dog
    {
    int age_puppy;

    public  puppy(int p){
       super(50);
        this.age_puppy=p;
        System.out.printf("The age of puppy received is %d\n",age_puppy);
    }

    public  puppy(){
        System.out.println("This puppy is super sweet ");
    }
}

public class CWR_37_this_super_keyword {
    public static void main(String[] args) {
//        puppy arnav=new puppy();
//        This invoke all the constructors which have no arguments

        puppy arnav=new puppy(45);


    }
}

