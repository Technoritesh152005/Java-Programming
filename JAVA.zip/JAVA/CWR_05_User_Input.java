import java.util.Scanner;
//By importing java.util.Scanner, you're making the Scanner class available in your program to take user input.
public class CWR_05_User_Input {
    public static void main(String[] args) {
        System.out.println("Taking input from user");
        Scanner sc= new Scanner(System.in);
//      this is necessary while taking input from keyboard bcz it act as a instance for a class and this is a object of class which we can use in any manner

        System.out.println("Enter a number 1");
//      int a =sc.nextInt();
        float a =sc.nextFloat();
//      the number 1 is stored in a and line 8 act as a scanner input
        System.out.println("Enter a number 2 ");
//      int b=sc.nextInt();
        float b=sc.nextFloat();
//        int sum=a+b;
        float sum=a+b;
        System.out.println("The sum of these numbers are : ");
        System.out.println(sum);

        sc.nextLine();
        // This is necessary to clear the newline character after numeric input

//        boolean b1 = sc.hasNextFloat();
//        System.out.println(b1);

        System.out.println("Enter a string ");
//        String str=sc.next();
//        this will read only one certain word and not whole line which have multiple words
        String name=sc.nextLine();
//        This will read whole line
//        System.out.println(str);
        System.out.println(name);



    }
}
