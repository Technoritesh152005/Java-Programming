import java.util.Scanner;
public class CWR_56_Exception_Handling {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        int[] marks = new int[3];
        marks[0]=33;
        marks[1]=45;
        marks[2]=99;

        System.out.println("Enter the index of the marks of which the value u want");
        int ind =sc.nextInt();
        System.out.println("Enter the number you want to divide");
        int num = sc.nextInt();

//        Try and catch is used to handle exception occured during the execution
        try{
            System.out.println("The number when divides the index value becomes:"+marks[ind]/num);
        }
//        Catches arithmetic exception which can occur when number attempted by user is 0 or null
        catch(ArithmeticException a){
            System.out.println(a);
        }
//        Catches this exception when user enters index value which is out of bound the size of array
        catch (ArrayIndexOutOfBoundsException b){
            System.out.println(b);
        }
//        Handle other exception
        catch(Exception e){
            System.out.println(e);
        }
    }
}
