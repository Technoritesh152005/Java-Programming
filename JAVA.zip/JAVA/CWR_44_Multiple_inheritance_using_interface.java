// First interface
    interface Flyable {
        void fly();
    }

    // Second interface
    interface Swimmable {
        void swim();
    }

    // Class implementing both interfaces
    class Duck implements Flyable, Swimmable {
        public void fly() {
            System.out.println("Duck is flying");
        }

        public void swim() {
            System.out.println("Duck is swimming");
        }
    }


// Main class
public class CWR_44_Multiple_inheritance_using_interface {
    public class Main {
        public static void main(String[] args) {
            Duck d = new Duck();
            d.fly();   // Output: Duck is flying
            d.swim();  // Output: Duck is swimming
        }
    }
}
