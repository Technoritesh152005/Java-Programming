public class CWR_26_Method_overloading {

//    Method overloading
    static void msg(){
        System.out.println("Hello i am a method where i don't have any parameters");
    }
    static void msg(int a){
        System.out.printf("Hello i am the same msg but the method call function have given me ONE argument , so my name is same but functions different and argument is %d \n",a);
    }
    static void msg(int a,int b){
        System.out.printf("Hello i am the same msg but the method call function have given me TWO argument , so my name is same but functions different and argument is %d and %d \n",a,b);
    }

//    Passing method to Array:
    static void arr(int [] array){
        array[0] =55;
    }



    public static void main(String[] args) {

            int []marks={24,45,56,67};
        System.out.printf("The value of index 0 before passing is %d \n",marks[0]);
            arr(marks);
        System.out.printf("The value of index 0 after passing is %d \n",marks[0]);

//        NOTE:when array is passed to method the copy is not being sent but the reference or address is been sent, so unlike where in array any change in value of array can disrupt the original value of array after calling it

//    Void method
//    static void write_anything(){
//
//        System.out.println("Hello i am void and i dont return value, i just print whatever i need to print and dont perform any operations");
//
//    }
//        write_anything();

//        Method overloading:
        msg();
        msg(5);
        msg(4,9);

//        Here 5,4 and 9 are arguments

//        In method overloading we can only change the parameters and not the return datatype of that method when there is two same method with same parameters
    }
}
