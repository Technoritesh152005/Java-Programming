import java.util.*;
//It creates an ArrayList with an initial capacity of 10 by default.
public class CWR_62_Array_list {
    public static void main(String[] args) {
        System.out.println("hello");
    }
}
