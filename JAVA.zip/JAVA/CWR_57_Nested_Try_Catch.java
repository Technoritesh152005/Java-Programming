import java.util.Scanner;
public class CWR_57_Nested_Try_Catch {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        int []number=new int[3];
        number[0]=44;
        number[1]=55;
        number[2]=99;
        int num1=77;

        try{
//            If the outer try catches exception it will directly give control to its execution and inner test will not implement
            System.out.println("Welcome to my code");
            System.out.println("Enter number 2");
            int num2=sc.nextInt();
            System.out.println(""+num1/num2);

//            Inside try block this will try to execute internally
//            1. Different parts of code may throw different exceptions
//            Sometimes, inside a try block, you might have another risky operation that also needs its own error handling.
                try{
                    System.out.println("Inner testing started");
                System.out.println("Enter the index value");
                int ind=sc.nextInt();
                    System.out.println("Index value is : "+number[ind]);
                }catch(ArrayIndexOutOfBoundsException a){
                System.out.println(a);
                }

        }catch (Exception b){
            System.out.println(b);
        }
        System.out.println("Program executed succesfully");
    }
}
