import java.util.Scanner;

public class CWR_17_Loops {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

//        While loops
        int a=1;
        while(a<=3){
            System.out.println(a);
            a++;
        }
//        While loops is a loop which will run till the condition gets meet true

//        quick quiz
//        while(a<=200){
//            System.out.println(a);
//            a++;
//        }

//        Do-while
//        int num=25;
//
//        do {
//            System.out.println(num);
//            num++;
//        }while (num<=20);

//        in Do while loop the code will always execute one time

//        For loop

//        For loop syntax is basically;
//        (initialization;condition;increment/decrement)

//        for (int a=1;a<=10;a++){
//            System.out.println(a);
//        }
//        int num=6;
//
//        for(int i=10;i>=1;i--){
//            System.out.printf("%d x %d = %d \n",num,i,num*i);
//        }


    }
}
