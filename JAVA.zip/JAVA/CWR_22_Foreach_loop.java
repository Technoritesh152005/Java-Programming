import java.util.Scanner;
public class CWR_22_Foreach_loop {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int []roll_number =new int[5];

//        Taking user input of array
        for ( int i = 0; i < 5; i++) {
            System.out.println("Enter the roll number");
            roll_number[i]=sc.nextInt();
        }

//        Displaying array using for loop
//        for (int j=0;j<roll_number.length;j++){
//            System.out.printf("The elements are %d \n",roll_number[j]);
//        }

//        Displaying array using for each loop
//        for(int element:roll_number){
//            System.out.println(element);
//        }

//        Displaying the array in reverse order
//        for (int j=roll_number.length-1;j>=0;j--){
//            System.out.printf("The elements are %d \n",roll_number[j]);
//        }
    }
}
