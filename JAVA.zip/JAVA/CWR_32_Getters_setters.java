
class Myemployee{

    private int id;
   private String name;

    public void setId(int id1){
        this.id=id1;
    }
    public void setName(String name1){
        this.name=name1;
    }
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }

}

//setter: means set the value to attribute which are private
//getter: means return the value of attribute

public class CWR_32_Getters_setters {
    public static void main(String[] args) {

        Myemployee Ritesh =new Myemployee();

//        Ritesh.id=25;
//        Ritesh.name="Ritesh Khilari";--> this will throw error due to private access modifier. this private access modifier helps in a way that only numbers given in id and restrict other character

//        Setting the private attributes
        Ritesh.setId(234);
        Ritesh.setName("Ritesh khilari");

//        Getting the private attributes

        System.out.printf("The id entered is %d\n",Ritesh.getId());
        System.out.printf("The name entered is %s\n",Ritesh.getName());

    }
}
