class phone {
    public void show_time(){
        System.out.println("Its currently 9 pm");
    }
    public void on(){
        System.out.println("Turning on phone");
    }
}
class smartphone extends phone{
    public void music(){
        System.out.println("Playing on the music");
    }
    @Override
    public void on(){
        System.out.println("Turning on smartphone");
    }

    public void gettingnames(String[] network) {
    }
}
//Method dispatching ek aisa technique hai jaha par reference superclass ka banaya jata hai aur object sub class ka ban jata hai.jab his tarah hum sub class ke object ke method se koi bhi method ko call karte hai toh woh hi method run hoga joh dono class meh hai except sabhi method class superclass ke toh run ho hi jayenge

public class CWR_39_Dynamic_MEthod_Dispatch {
    public static void main(String[] args) {

          phone obj=new smartphone();
//        Allowed
//        hum ek smartphone ko phone bol sakte hai

//        smartphone obj2=new phone();
//        Not allowed
//        par ek phone ko smartphone nahi bol sakte hai

//        humne phone ek reference liya hai jaha object toh smartphone ka hai aur woh running time meh create hota hai
//        jab hum obj override method ko call karenge toh woh jiss class ka object hai wh call karega

        obj.on();
//        Ab jese yaha par object smartphone ka baana hai toh on bhi smartphone hi hoga na ki phone

//        obj.music();
//        Not allowed
//        YEH allowed nahi hai kyuki yeh ek esa method hai joh main toh apne superclass me available nhi hai

        obj.show_time();
//        Allowed kyuki smartphone inherit hai apne phone se

    }
}
