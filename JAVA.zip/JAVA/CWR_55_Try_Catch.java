
public class CWR_55_Try_Catch {
    public static void main(String[] args) {
        int a=456;
        int b=0;
        System.out.println("Program started");

//        Te advantage of try catch is it atleast try and if exception occurs it dont stop the flow of execution. it continue further part of code
//        Exception can be a sudden event which can disrupt the flow of execution
        try{
            int c=a/b;
            System.out.println("The number divided 456 by 0 is : \n"+c);
        }catch (Exception e){
            System.out.println("The process of division is not possible cause error has occured.The error reason is : \n"+e);
        }
        System.out.println("End of the progarm");
    }
}
