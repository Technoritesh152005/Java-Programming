import java.lang.Thread;
class Mythread extends Thread{

    public Mythread(String name){
        super(name);
    }
    public void run(){
        while(true){
            System.out.println("Name of the thread is : "+this.getName());
        }
    }
}
public class CWR_52_Thread_priorities {
    public static void main(String[] args) {
        Mythread t1=new Mythread("hello");
        Mythread t2=new Mythread("stay");
        Mythread t3=new Mythread("alert");
        Mythread t4=new Mythread("from");
        Mythread t=new Mythread("me");

        t1.setPriority(Thread.MIN_PRIORITY);
        t2.setPriority(Thread.MAX_PRIORITY);
        t3.setPriority(Thread.MIN_PRIORITY);
        t4.setPriority(Thread.MIN_PRIORITY);
        t.setPriority(Thread.MIN_PRIORITY);
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t.start();

    }
}
