import java.util.Scanner;
public class CWR_11_Strings_Methods {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a string");
        String name=sc.nextLine();

        int length =name.length();
        System.out.printf("the length is %d\n",length);
        System.out.println(name.length());

        System.out.println(name.toLowerCase());
        String lowercase=name.toLowerCase();
        System.out.println(lowercase);

        System.out.println(name.toUpperCase());
        String uppercase=name.toLowerCase();
        System.out.println(uppercase);

        String trimname="    Ritesh    ";
        System.out.println(trimname.trim());
//        Trim function is used to remove extra space from the string content

//        System.out.println(name.substring(2));
//        it includes all content of string from index 2 to till the end
//        System.out.println(name.substring(2,9));
//        it takes all character from index 2 -> 9 but do not include the character at index 9

//        String replacename=name.replace('r','p');
//        String replacename=name.replace("ite","hell");
//        System.out.println(replacename);

//        boolean torf=name.startsWith("Rit");
//        System.out.println(torf);

        System.out.println(name.endsWith("fal"));
//        char index=name.charAt(2);
//        System.out.println(index);

        System.out.println(name.indexOf("es"));
//        it gives the index int value of es in string content

        //System.out.println(name.indexOf("es",5));
//        it starts to search index of es after the index 5 and all the content before index 5 are ignored

//        boolean yesorno=name.equals("ritesh");
//        System.out.println(yesorno);
//        it is case sensitive and returns true or false if the content matches with the entered string

//        boolean yesorno=name.equalsIgnoreCase("ritesh");
//        System.out.println(yesorno);
//this is not case sensitive and do not support on either uppercase or lowercase but only focuses on thr matched content

    }
}
