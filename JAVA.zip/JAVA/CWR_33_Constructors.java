class My_main_employee{

    int id;
    String name;
    int age;

//    constructors have the name of the class

//    Constructor1
    public My_main_employee(){
        id=44;
        name="Ritesh khilari";
        age=44;
    }

//    Here in this constructors the value is set for all objects of this class. we can even pass arguments and parameters to it
//    Here both constructor 1 and 2 are a example of constructors overloading


//    Constructor method( constructor2)
    public My_main_employee(String his_name,int his_id,int his_age){

    id=his_id;
    name=his_name;
    age=his_age;

    }

//    public int getid(){
//        return id;
//    }
//    public String getname(){
//        return name;
//    }
//    public int getage(){
//        return age;
//    }
//    Jab bhi koi arguments pass kiya hoga constructors ko toh woh us constructor ke pas jayega jaha parameters hai like ex constructor 2 aur jaha koi arguments pass nhi kiya waha constructor 1 peh jayega
}

public class CWR_33_Constructors {
    public static void main(String[] args) {

        My_main_employee Ritesh=new My_main_employee("Ritesh Khilariiii",956,290);

//        Ritesh.id=456;
//        Ritesh.name="Ritesh khilari";
//        Ritesh.age=34;
//        Suppose the data was same for all attributes and there were many objects so it would be difficult to set the value manually
//        so constructors are used which gets invoked automatically and sets the values its own

        System.out.println(Ritesh.age);
        System.out.println(Ritesh.id);
        System.out.println(Ritesh.name);
    }
}

//Quick Quiz
//class setsalary{
//    int empsalary;
//    public setsalary(){
//        empsalary=10000;
//        System.out.printf("%d\n",empsalary);
//    }
//    public setsalary(int other){
//        empsalary=other;
//        System.out.printf("%d",empsalary);
//    }
//
//}
//public class CWR_33_Constructors {
//    public static void main(String[] args) {
//        setsalary e1=new setsalary();
//        setsalary e2=new setsalary(20000);
//
//
//
//    }
//}