import java.util.Scanner;

public class CWR_19_Practice_05 {
    public static void main(String[] args) {

//        Question 1
        for (int i = 4; i >= 1; i--) {  // Loop to control the number of rows
            for (int j = 1; j <= i; j++) {  // Loop to print stars in each row
                System.out.print("*");
            }
            System.out.println();  // Move to the next line after printing stars
        }
//        Question 2
//     int a =2;
//    while(a<=20){
//        System.out.println(a);
//        a+=2;

//        Question 3
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter the multiplication table you want");
//        int num=sc.nextInt();
//        for (int i=1;i<=10;i++){
//            System.out.printf(" %d X %d = %d \n",num,i,num*i);
//        }
//        Question 4
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter the multiplication table you want");
//        int num=sc.nextInt();
//        for (int i=10;i>=1;i--){
//            System.out.printf(" %d X %d = %d \n",num,i,num*i);
//        }

//        Question 5

//      Scanner sc=new Scanner(System.in);
//        System.out.println("Enter the factorial you want");
//        int num=sc.nextInt();
//        int factorial =1;
//
//        for (int i=1;i<=num;i++){
//            factorial=factorial*i;
//        }
//        System.out.printf("The factorial is : %d \n",factorial);

//        Question 6
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter the factorial you want");
//        int num=sc.nextInt();
//        int factorial =1;
//        int i=1;
//
//
//        while(i<=num){
//            factorial=factorial*i;
//            i++;
//        }
//        System.out.println(factorial);

//        Question 7
//        Scanner sc=new Scanner(System.in);
//        System.out.println("Enter the multiplication sum you want");
//        int num=sc.nextInt();
//        int sum=0;
//
//
//        for (int i=1;i<=10;i++){
//            int product=num*i;
//            System.out.printf("%d X %d = %d \n",num,i,product);
//            sum=sum+product;
//
//        }
//        System.out.println(sum);Scanner sc=new Scanner(System.in);
//        System.out.println("Enter the multiplication sum you want");
//        int num=sc.nextInt();
//        int sum=0;
//
//
//        for (int i=1;i<=10;i++){
//            int product=num*i;
//            System.out.printf("%d X %d = %d \n",num,i,product);
//            sum=sum+product;
//
//        }
//        System.out.println(sum);

//for(int i=5;i>=1;i--){
//    for (int j=1;j<=i;j++){
//        System.out.printf("*");
//    }
//    System.out.println();
//}


    }
}
