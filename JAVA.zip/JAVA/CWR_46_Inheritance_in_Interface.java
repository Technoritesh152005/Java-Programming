import java.security.PublicKey;

interface sample{
    public void meth1();
    public void meth2();
}

//Remember
//WHEN INTERFACE INHERIT FROM INTERFACE WE USE EXTEND KEYWORD AND WHEN CLASS INHERIT FROM INTERFACE WE USE IMPLEMENTS KEYWORD
//THE SAMPLEKABETA HAS METHOD 1 AND 2 IN IT AS IT IS INHERITED FROM IT
interface samplekabeta extends sample{
    public void meth3();
    public void meth4();
}

//SO HERE AS SAMPLE KA NATU IMPLEMENTS SAMPLE AKA BETA HW MUST OVERRIDE OR COMPULSORY USE THESE INTERFACE METHOD 3 AND 4 AND HE CAN ALOS ACCESS METH 1 AND 2 AS IT IS IN IT WHEN WE CRAETE THE OBJECT OF SAMPLEKANATU

class samplekanatu implements samplekabeta{
    public void meth1(){
        System.out.println("Meth1");
    }
    public void meth2(){
        System.out.println("Meth2");
    }
    public void meth3(){
        System.out.println("Meth3");
    }
    public void meth4(){
        System.out.println("Meth4");
    }
}
public class CWR_46_Inheritance_in_Interface {
    public static void main(String[] args) {

samplekanatu sb=new samplekanatu();
sb.meth1();
sb.meth2();
sb.meth3();

    }
}
