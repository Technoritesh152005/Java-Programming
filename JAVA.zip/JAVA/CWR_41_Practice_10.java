class circle {
    float radius;
    double areac;

    public void setRadius(float radius) {
        this.radius = radius;
    }

    public double circlearea() {
        areac = Math.PI * radius * radius;
        System.out.printf("The area of the circle is %.2f\n", areac);
        return areac;
    }
}

class cylinder1 extends circle {
    float height;

    public void setHeight(float height) {
        this.height = height;
    }

    public void cylinderarea() {
        double areacy = (2 * Math.PI * radius * radius) + (2 * Math.PI * radius * height);
        System.out.printf("The surface area of the cylinder is %.2f\n", areacy);
    }

    public void cylindervolume() {
        double volcy = areac * height;
        System.out.printf("The volume of the cylinder is %.2f\n", volcy);
    }
}

public class CWR_41_Practice_10 {
    public static void main(String[] args) {
        cylinder1 user1 = new cylinder1();
        user1.setRadius(20);
        user1.setHeight(20);

        user1.circlearea();     // first calculate area and store in areac
        user1.cylindervolume(); // now areac is available
        user1.cylinderarea();
    }
}
