
class Myexception1{
//    Throws is a keyword in java which warns the user who is using this method to inform that Arithmetic exception can ccur from this method nd u handle the inputs from ur own using try catch block
    public void divide(int a,int b)throws ArithmeticException{
        if (a==0||b==0){
            throw new  ArithmeticException("Number cannot be 0");
        }
        int c=a/b;
        System.out.println(c);
    }
}

class NegativeRadiusException extends Exception{
    @Override
    public String toString() {
        return "The radius cannot be negative";
    }

}

class Myexception2 extends NegativeRadiusException {

public void area(float r)throws NegativeRadiusException{
//    We use throws to pass the responsibility of handling the exception to the caller of the method — instead of handling it inside the method.
    if (r<0){
        throw new NegativeRadiusException();
    }
    double result=Math.PI*r*r;
    System.out.println(result);
}
}

public class CWR_58_Throw_Throws {
    public static void main(String[] args) {
        Myexception1 m=new Myexception1();
//        So, Java does not force you to handle it using try-catch or throws.
//🔍 Types of Exceptions in Java:
//        Type	Example	Must use throws or try-catch?
//✅ Checked Exception	IOException, SQLException	Yes (must handle)
//❌ Unchecked Exception	ArithmeticException, NullPointerException, ArrayIndexOutOfBoundsException

      try{
          m.divide(6,0);
      }catch (Exception e){
          System.out.println(e);
      }

//
        Myexception2 d=new Myexception2();
      try{
          d.area(-9);
      }catch (Exception e){
          System.out.println(e);

      }

    }
}
