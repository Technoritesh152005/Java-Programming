import java.util.Scanner;
public class CWR_13_Conditional_Statements {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your age");
        int age=sc.nextInt();

        if (age>=18){
            System.out.println("you are eligible to drive");
        }
        else{
            System.out.println("You are not eligible to drive");
        }


    }
}
