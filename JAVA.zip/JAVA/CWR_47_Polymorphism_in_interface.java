import java.util.Scanner;
interface shape{
    public void area();
}
class Circle implements shape{
    Scanner sc=new Scanner(System.in);

    public  void area(){
        System.out.println("Enter the radius");
        float radius=sc.nextFloat();
        System.out.printf("The area of the circle is %.2f\n",Math.PI*radius*radius);
    }
}
class rectangle implements shape{
    Scanner sc=new Scanner(System.in);


    public  void area(){
        System.out.println("Enter the length");
        int length=sc.nextInt();
        System.out.println("Enter the breadth");
        int breadth=sc.nextInt();
        System.out.printf("The area of the circle is %f",length,breadth);
    }
}
public class CWR_47_Polymorphism_in_interface {
    public static void main(String[] args) {
shape ref=new Circle();
ref.area();

shape ref2=new rectangle();
ref2.area();
    }
}
