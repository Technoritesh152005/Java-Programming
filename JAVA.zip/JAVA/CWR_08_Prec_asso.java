public class CWR_08_Prec_asso {
    public static void main(String[] args) {
//        int a=3;
//        int b=5;
//        int c= a*b -b/a;
//        from parenthesis rule * and / have highest precedence and then comes the associativity law that is from left to right
//        System.out.println(c);

//        Quick quiz
        int a=2 ;
        int b=3;
        int c = a-b/2;
        System.out.println(c);
        int d=(b*b -4*a*c)/(2*a);
        System.out.println(d);

    }
}
