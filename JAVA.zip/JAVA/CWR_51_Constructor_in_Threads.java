//class mycircle extends Thread{
//    public mycircle(String name){
//
////        In your code, super(name); is used inside the constructor of your class MyThr which extends the Java Thread class.
////
////🔍 What super(name) does:
////        It calls the constructor of the parent class (Thread) and passes the name argument to it.
////
////        In other words:
//
////        Java’s Thread class has a constructor like this:
////
////
////public Thread(String name)
////        This constructor sets the name of the thread, which can later be retrieved using getName().
//        super(name);
//    }
//    public void run(){
//        int i=0;
//        while(i<300000) {
//            System.out.println("Today is 16th of july 2025.Hope one day you see this code u will be proud for urself at that moment");
//            i++;
//        }
//    }
//}
//public class CWR_51_Constructor_in_Threads {
//    public static void main(String[] args) {
//        mycircle m=new mycircle("Threadname");
//        mycircle m1=new mycircle("Threadname");
//       // m.start();
//        System.out.println("The name of the thread is : "+m.getName());
//        System.out.println("The id of the thread is : "+m.getId());
//        System.out.println(m1.getPriority());
//
//
//    }
//
//}

//When you extend Thread:
//You are inheriting from the Thread class, so you can call super(name) to call the parent (Thread class) constructor and set the name.
class MyTask implements Runnable {
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println("Running: " + Thread.currentThread().getName());
        }
    }
}

//When you use Runnable with Thread constructor:
//You are not extending Thread, you're creating a separate Runnable class.
//
//Then, you create a Thread object like this:

public class CWR_51_Constructor_in_Threads {
    public static void main(String[] args) {
        MyTask task = new MyTask(); // object of class that implements Runnable

        Thread t1 = new Thread(task, "MyRunnableThread"); // using (Runnable, String) constructor

        t1.start(); // start the thread

        System.out.println("Thread name: " + t1.getName());
        System.out.println("Thread ID: " + t1.getId());
    }
}
