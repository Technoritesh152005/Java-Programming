//It is a superclass or parent class of inheritance
class base{

    int x;

    public void set_x(int X){
        System.out.println("I am setting the value of x in base class");
        this.x=X;
    }
    public int get_x(){
        return x;
    }

}

//    It is a subclass or child class which has all the properties of its superclass or parent class and it can access which depends on its access modifier
class derived extends base{

    int y;
    public void set_y(int Y){
        this.y=Y;
    }
    public int get_y(){
        return y;
    }
}

public class CWR_35_Inheritance {
    public static void main(String[] args) {

//        Creating an object of base class
        base a=new base();
        a.set_x(45);
        System.out.printf("The value of x in base class is %d\n",a.get_x());

//        Creating an object of derived class
        derived b=new derived();
        b.set_y(33);
        System.out.printf("The value of y in derived class is %d\n",b.get_y());

        b.set_x(100);
        System.out.printf("The value of x after setting from derived class is %d\n",b.get_x());
    }
}
