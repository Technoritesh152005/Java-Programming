import java.util.Random;
import java.util.Scanner;

public class CWR_20_Project_1 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        char comp = ' ', player;  // Default initialization of 'comp'
//        The reason comp was initially assigned the value 'r' was to prevent an error where the compiler might complain about the variable not being initialized before use. This assignment serves as a safeguard.
        Random random = new Random();
        int randomNumber = random.nextInt(100) + 1;  // Generates a number between 1 and 100


        // Assigning comp based on randomNumber
        if (randomNumber > 0 && randomNumber <= 33) {
            comp = 'r';
        } else if (randomNumber > 33 && randomNumber <= 66) {
            comp = 'p';
        } else if (randomNumber > 66 && randomNumber <= 100) {
            comp = 's';
        }

        System.out.println("Welcome to the ROCK PAPER SCISSORS GAME");
        System.out.println("Enter START to start the game");
        String process = sc.nextLine();

        System.out.println("Press 'r' for rock \n Press 'p' for paper \n Press 's' for scissors");
        player = sc.next().charAt(0);

        // Loop continues as long as process is "start"
        while (process.equalsIgnoreCase("start")) {

            if (player == 'r' && comp == 'p') {
                System.out.println("You lose! Try once again.");
            } else if (player == 'r' && comp == 's') {
                System.out.println("Congrats, you won!");
            } else if (player == 'r' && comp == 'r') {
                System.out.println("MATCH TIED!");
            } else if (player == 'p' && comp == 'p') {
                System.out.println("MATCH TIED!");
            } else if (player == 's' && comp == 's') {
                System.out.println("MATCH TIED!");
            } else if (player == 'p' && comp == 'r') {
                System.out.println("Congrats, you WIN!");
            } else if (player == 's' && comp == 'r') {
                System.out.println("You LOSE!");
            } else if (player == 's' && comp == 'p') {
                System.out.println("You WIN!");
            } else {
                System.out.println("Invalid input, does not match!");
            }

            break;  // End the game after one round
        }

        sc.close();
    }
}
