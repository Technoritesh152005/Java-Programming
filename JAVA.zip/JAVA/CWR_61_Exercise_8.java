import java.util.*;
class customcalculator{
    Scanner sc=new Scanner(System.in);

    public void add() throws Exception{

        int a=0;
        int b=0;
        try{
            System.out.println("Enter Number 1");
             a=sc.nextInt();
            System.out.println("Enter Number 2");
          b=sc.nextInt();
        }catch(Exception e){
            System.out.println("Invalid input exception");

        }

        try {

            if (a>100000||b>100000){
                throw new Exception("Max Input Exception");
            }
            int c=a+b;
            System.out.println(c);
        }catch(Exception e){
            System.out.println(e);

        }
    }
    public void sub(){
        int a=0;
        int b=0;
        try{
            System.out.println("Enter Number 1");
            a=sc.nextInt();
            System.out.println("Enter Number 2");
            b=sc.nextInt();
        }catch(Exception e){
            System.out.println("Invalid input exception");
//            Also, after catching invalid input, you should return; or handle re-prompting — otherwise, the next logic uses default values like 0.
            return;

        }

        try {

            if (a>100000||b>100000){
                throw new Exception("Max Input Exception");
            }
            int c=a-b;
            System.out.println(c);
        }catch(Exception e){
            System.out.println(e);

        }
    }
    public void mult(){
        int a=0;
        int b=0;
        try{
            System.out.println("Enter Number 1");
            a=sc.nextInt();
            System.out.println("Enter Number 2");
            b=sc.nextInt();
        }catch(Exception e){
            System.out.println("Invalid input exception");

        }

        try {

            if (a>7000||b>7000){
                throw new Exception("Max Input Exception");
            }
            int c=a*b;
            System.out.println(c);
        }catch(Exception e){
            System.out.println(e);

        }
    }
    public void div(){
        int a=0;
        int b=0;
        try{
            System.out.println("Enter Number 1");
            a=sc.nextInt();
            System.out.println("Enter Number 2");
            b=sc.nextInt();
        }catch(Exception e){
            System.out.println("Invalid input exception");

        }

        try {

            if (a>100000||b>100000 ){
                throw new Exception("Max Input Exception");
            }else if (b==0){
                throw new Exception("Cannot divide by 0");
            }
            int c=a/b;
            System.out.println(c);
        }catch(Exception e){
            System.out.println(e);

        }
    }
    }

public class CWR_61_Exercise_8 {
    public static void main(String[] args) {

        customcalculator c = new customcalculator();
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter + for addition,- for Substraction, * for multiplication,/ for division");
        char op = sc.next().charAt(0);


            switch (op) {
                case '+':
                    try {
                        c.add();
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case '-':
                    try {
                        c.sub();
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case '*':
                    try {
                        c.mult();
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                case '/':
                    try {
                        c.div();
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    break;
                default:
                    System.out.println("Bye Bye");

            }

    }
}
