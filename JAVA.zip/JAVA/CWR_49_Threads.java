
//Creating a thread by extending Threads
class Thread1 extends Thread{

    int i=0;
//    In Java, the run() method is the entry point for a thread.
//    It contains the code that will be executed in a separate thread when the thread is started.
        public void run(){
            while(i<40000){
            System.out.println("I am cooking for myself");
            System.out.println("I am washing dish also");
            i++;
        }
    }

}
class Thread2 extends Thread{
    int i=0;
    @Override
    public void run(){
        while (i<40000){
            System.out.println("I am studying for myself");
            System.out.println("I am studying SQl now");
            i++;
        }

    }
}
public class CWR_49_Threads {
    public static void main(String[] args) {
        Thread1 t1=new Thread1();
        Thread2 t2=new Thread2();

        t1.start();
        t2.start();
    }

}

//When you call:
//
//java
//        Copy
//Edit
//t1.start(); // starts Thread1
//t2.start(); // starts Thread2
//Java's Thread Scheduler decides:
//
//When each thread gets to run
//
//For how long it runs before switching to the other thread
//
//It switches back and forth very fast, so both threads appear to run at the same time (concurrently).

