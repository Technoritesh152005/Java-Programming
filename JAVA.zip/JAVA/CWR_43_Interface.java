interface  Bicycle{

//    all the properties in the interface are final and u cannot modify it
int a=88;

//    Interface is also like an abstract but in abstract class it can contain abstract and non abstract methods. but in interface everything inside it will be interface method
//     Same like abstract the interface methods will not have body but these methods must all be executed when a class is impplemented from this parent class
    void stop();
     void accelerate();
}

//it cannot use extends keyword but must use implements for interface
class dochakk implements Bicycle{
   public void stop(){
       System.out.println("Thr dochakka is getting stopped");
    }
    public void accelerate(){
        System.out.println("The dochakka is getting accelerated");
    }
}
public class CWR_43_Interface {
    public static void main(String[] args) {
    Bicycle b=new dochakk();
    b.stop();
    b.accelerate();

//    It is possible u can us ethe properties of interface
        System.out.println(b.a);

//        It is not possible bcz u cannot modifyy the properties into interface as they r final
//        b.a=888;
    }
}
//Feature	Explanation
//Keyword	interface
//Methods	All methods are abstract (no body), unless declared default or static (Java 8+)
//Variables	All variables are public static final (i.e., constants)
//Inheritance	A class can implement multiple interfaces
//        Object Creation	❌ You cannot create an object of an interface