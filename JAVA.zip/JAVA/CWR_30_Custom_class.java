

class Humanproperties{
//    Humanproperties is a class

    String blood_group;
    int Haemoglobin;
    int age;
    String name;
    String Father_name;
//    here all these are its attributes

    public void details(){
        System.out.printf("The name is %s\n",name);
        System.out.printf("and his father name is %s",Father_name);
    }

}

public class CWR_30_Custom_class {
    public static void main(String[] args) {

        Humanproperties Ritesh=new Humanproperties();
        Humanproperties Vishal=new Humanproperties();
//        Many objects can be created from a class
//        Instantiating a new Ritesh object

//        Setting the value to the attributes
        Ritesh.blood_group="AB";
        Ritesh.age=19;
        Ritesh.Haemoglobin=12;
        Ritesh.name="Ritesh khilari";
        Ritesh.Father_name="Dattatray Khilari";

//        Printing the attributes for object Ritesh
        System.out.println(Ritesh.blood_group);
        Ritesh.details();
        System.out.println(" ");

//        Setting the value of attributes to Class
        Vishal.blood_group="O";
        Vishal.age=30;
        Vishal.Haemoglobin=15;
        Vishal.name="Vishal Godase";
        Vishal.Father_name="Dharmaraj Godase";

//        Printing the attributes of vishal object
        System.out.println(Vishal.blood_group);
        System.out.println(Vishal.age);
        System.out.println(Vishal.Haemoglobin);
        Vishal.details();




    }
}




























