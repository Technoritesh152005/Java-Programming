public class CWR_27_vaargs {

//    static int sum(int a, int b){
//        return a+b;
//    }
//    static int sum(int a, int b,int c){
//        return a+b+c;
//    }
//    static int sum(int a, int b,int c,int d){
//        return a+b+c+d;
//    }

//    VAARGS:
//    The ... after the data type tells Java that the method can receive 0 or more arguments of that type
    static  int sum(int ...arr){
//        it acts like an array int [] arr;
        int result=0;

        for (int i=0;i<arr.length;i++){
            result=result+arr[i];
        }
        return result;
    }
    public static void main(String[] args) {
        System.out.printf("The sum of 3 and 3 is %d: \n",sum(3,3));
        System.out.printf("The sum of 3 and 3 and 6  is %d: \n",sum(3,3,6));
        System.out.printf("The sum of 3 and 3 and 2 and 4 is %d: \n",sum(3,3,2,4));

    }
}
