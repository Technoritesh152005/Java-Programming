public class CWR_28_Recursion {

    static int factorial_iterative(int b){
        int product=1;
        for (int i=1;i<=b;i++){

            product =product*i;
        }
        return product;
    }

    static int factorial_recursion(int x){
        int factorial=1;
        if(x==0||x==1){
            return 1;
        }
        else{
            return x*factorial_recursion(x-1);
        }
    }

    public static void main(String[] args) {
        int a=5;
        System.out.printf("The factorial of %d will be %d:",a,factorial_iterative(a) );
        System.out.println(" ");
        System.out.printf("The factorial of %d will be %d:",a,factorial_recursion(a) );
    }
}
